# REEYX STUDIO — Vercel + Discord OAuth

## Deploy
1. Upload folder project ini ke repository GitHub.
2. Import repository di Vercel.
3. Framework Preset: Other. Root Directory: `./`.
4. Di Vercel → Project → Settings → Environment Variables, tambahkan:
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `DISCORD_REDIRECT_URI`
   - `SESSION_SECRET`
5. Deploy / Redeploy project.

## Discord OAuth setup
1. Buka https://discord.com/developers/applications
2. Buat application REEYX STUDIO.
3. Buka OAuth2 → Redirects.
4. Tambahkan URL callback persis seperti:
   `https://DOMAIN-KAMU.vercel.app/auth/discord/callback`
5. Salin Application ID sebagai `DISCORD_CLIENT_ID`, dan Client Secret sebagai `DISCORD_CLIENT_SECRET`.
6. Set `DISCORD_REDIRECT_URI` ke URL callback yang sama persis.
7. OAuth scope yang dipakai adalah `identify`.

## SESSION_SECRET
Buat nilai acak panjang minimal 32 karakter. Jangan gunakan contoh atau membagikannya ke siapa pun.

## Penting
- Jangan pernah commit `.env` atau menaruh Client Secret / SESSION_SECRET di browser.
- Login ini hanya mengambil ID, username, display name, dan avatar Discord.
- Fitur role Discord, upload Roblox Open Cloud, database, dan pembayaran belum terhubung.
- Gunakan HTTPS (domain Vercel) karena cookie sesi menggunakan Secure.
