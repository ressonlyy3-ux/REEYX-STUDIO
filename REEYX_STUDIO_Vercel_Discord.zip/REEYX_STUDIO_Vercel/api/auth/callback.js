const { requiredEnv, encodeSigned, decodeSigned, cookies, setCookie, clearCookie, safeEqual } = require("../_auth");

module.exports = async (req, res) => {
  if (req.method !== "GET") return res.status(405).send("Method not allowed");
  const missing = requiredEnv();
  if (missing.length) return res.status(500).send(`Environment variables belum diisi: ${missing.join(", ")}`);

  const savedState = decodeSigned(cookies(req).reeyx_oauth_state);
  const returnedState = req.query.state;
  const code = req.query.code;
  if (!savedState || !safeEqual(savedState.state, returnedState) || !code) {
    clearCookie(res, "reeyx_oauth_state");
    return res.redirect(302, "/?login=failed#login");
  }

  try {
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env.DISCORD_CLIENT_ID,
        client_secret: process.env.DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code",
        code,
        redirect_uri: process.env.DISCORD_REDIRECT_URI
      })
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) throw new Error("Discord token exchange failed");

    const userResponse = await fetch("https://discord.com/api/users/@me", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const user = await userResponse.json();
    if (!userResponse.ok || !user.id) throw new Error("Could not fetch Discord profile");

    const session = encodeSigned({
      user: { id: user.id, username: user.username, global_name: user.global_name, avatar: user.avatar },
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000
    });
    setCookie(res, "reeyx_session", session, 7 * 24 * 60 * 60);
    clearCookie(res, "reeyx_oauth_state");
    return res.redirect(302, "/#login");
  } catch (error) {
    console.error("Discord OAuth callback error:", error.message);
    clearCookie(res, "reeyx_oauth_state");
    return res.redirect(302, "/?login=failed#login");
  }
};
