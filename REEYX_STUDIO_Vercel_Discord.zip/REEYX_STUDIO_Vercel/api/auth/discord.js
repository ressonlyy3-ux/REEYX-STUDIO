const { requiredEnv, encodeSigned, setCookie } = require("../_auth");

module.exports = (req, res) => {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  const missing = requiredEnv();
  if (missing.length) return res.status(500).json({ error: `Environment variables belum diisi: ${missing.join(", ")}` });

  const state = require("node:crypto").randomBytes(24).toString("hex");
  const signedState = encodeSigned({ state, exp: Date.now() + 10 * 60 * 1000 });
  setCookie(res, "reeyx_oauth_state", signedState, 600);

  const authorize = new URL("https://discord.com/oauth2/authorize");
  authorize.search = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: process.env.DISCORD_REDIRECT_URI,
    response_type: "code",
    scope: "identify",
    state
  }).toString();
  res.redirect(302, authorize.toString());
};
