const { decodeSigned, cookies } = require("./_auth");

module.exports = (req, res) => {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });
  res.setHeader("Cache-Control", "no-store");
  const session = decodeSigned(cookies(req).reeyx_session);
  return res.status(200).json({ user: session?.user || null });
};
