const crypto = require("node:crypto");

function requiredEnv() {
  const names = ["DISCORD_CLIENT_ID", "DISCORD_CLIENT_SECRET", "DISCORD_REDIRECT_URI", "SESSION_SECRET"];
  const missing = names.filter(n => !process.env[n]);
  return missing;
}
function sign(value) {
  return crypto.createHmac("sha256", process.env.SESSION_SECRET).update(value).digest("base64url");
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function encodeSigned(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${sign(body)}`;
}
function decodeSigned(value) {
  if (!value || !process.env.SESSION_SECRET) return null;
  const [body, signature] = value.split(".");
  if (!body || !safeEqual(signature, sign(body))) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString());
    if (!payload.exp || payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
function cookies(req) {
  const raw = req.headers.cookie || "";
  return Object.fromEntries(raw.split(";").map(v => v.trim()).filter(Boolean).map(v => {
    const i = v.indexOf("="); return [v.slice(0, i), v.slice(i + 1)];
  }));
}
function setCookie(res, name, value, maxAge) {
  res.setHeader("Set-Cookie", `${name}=${value}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`);
}
function clearCookie(res, name) {
  res.setHeader("Set-Cookie", `${name}=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`);
}
module.exports = { requiredEnv, encodeSigned, decodeSigned, cookies, setCookie, clearCookie, safeEqual };
